Planet Learn Languages Bot — Railway Deployment

1. Скопируй все файлы в Railway (через GitHub или вручную).
2. Укажи переменные окружения (перейди в Settings → Variables):
   - BOT_TOKEN=<твой токен Telegram бота>
   - ADMIN_ID=<твое Telegram ID для оповещений>
3. Установи зависимости (автоматически через requirements.txt).
4. Запусти main.py и наблюдай запуск.
